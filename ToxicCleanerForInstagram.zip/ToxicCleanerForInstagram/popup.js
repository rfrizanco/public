let countdownInterval = null;
let processRunning = false;
let loadingData = false;


function createProgressBar(current, total) {

  const maxBlocks = 20;

  if (!total || total === 0) {
    return "░".repeat(maxBlocks);
  }

  const ratio = current / total;

  const blocks = Math.floor(ratio * maxBlocks);

  const filled = "█".repeat(blocks);
  const empty = "░".repeat(maxBlocks - blocks);

  return `${filled}${empty}`;
}

function setButtonsDisabled(disabled) {
  document.querySelectorAll("button").forEach(btn => {
    if (btn.id !== "cancel") {
      btn.disabled = disabled;
      btn.style.opacity = disabled ? "0.5" : "1";
      btn.style.cursor = disabled ? "not-allowed" : "pointer";
    }
  });
}

document.getElementById("load").addEventListener("click", async () => {

  if (processRunning || loadingData) return;

  const username = document
    .getElementById("targetUser")
    .value
    .replace("@", "")
    .trim();

  const ignoreInput = document.getElementById("ignoreUsers").value;

  const ignoreList = ignoreInput
    .split(";")
    .map(u => u.trim().toLowerCase())
    .filter(Boolean);

  chrome.storage.local.set({
    lastUsername: username,
    ignoreUsers: ignoreInput
  });

  if (!username) {
    document.getElementById("status").innerText =
      "Informe o username a ser analisado.";
    return;
  }

  loadingData = true;

  const loadButton = document.getElementById("load");
  const status = document.getElementById("status");

  loadButton.disabled = true;
  loadButton.style.opacity = "0.5";

  status.innerText = `Carregando dados de @${username}...`;
  document.getElementById("barFollowers").style.width = "0%";
  document.getElementById("barFollowing").style.width = "0%";

  const tabs = await chrome.tabs.query({
    url: "*://www.instagram.com/*"
  });

  const tab = tabs.find(t => !t.url.includes("/direct/")) || tabs[0];

  if (!tab) {
    status.innerText = "Abra o Instagram em uma aba primeiro.";
    return;
  }

  chrome.tabs.sendMessage(tab.id, {
    action: "LOAD_DATA",
    username: username,
    ignoreList: ignoreList
  }, (response) => {

    loadingData = false;
    loadButton.disabled = false;
    loadButton.style.opacity = "1";

    if (chrome.runtime.lastError) {
      status.innerText =
        "A página do Instagram ainda está carregando. Aguarde alguns segundos.";
      return;
    }

    if (!response || response.error) {
      status.innerText = response?.error || "Erro ao carregar.";
      return;
    }

    status.innerText = "";
    document.getElementById("progressFollowers").style.display = "none";
    document.getElementById("progressFollowing").style.display = "none";

    document.getElementById("summary").innerText =
      `Seguidores: ${response.followers}
Seguindo: ${response.following}
Não seguem você: ${response.notFollowingBack}`;

    const resultDiv = document.getElementById("result");
    resultDiv.innerHTML = "";

    response.list.forEach(user => {

      const div = document.createElement("div");
      div.className = "user";

      div.innerHTML = `
        <input class="removeUser" type="checkbox" data-id="${user.id}">
        <input class="celebrityUser" type="checkbox" data-username="${user.username}">
        <a href="#" data-url="${user.profileUrl}">
          ${user.username} (${user.fullName})
        </a>
      `;

      const link = div.querySelector("a");

      link.addEventListener("click", (e) => {
        e.preventDefault();

        chrome.tabs.create({
          url: link.dataset.url,
          active: false
        });
      });

      
      const celebBox = div.querySelector(".celebrityUser");

        celebBox.addEventListener("change", () => {

          const username = celebBox.dataset.username.toLowerCase();

          chrome.storage.local.get(["ignoreUsers"], (result) => {

            let list = result.ignoreUsers || "";

            let arr = list
              .split(";")
              .map(u => u.trim().toLowerCase())
              .filter(Boolean);

            if (!arr.includes(username)) {
              arr.push(username);
            }

            const newList = arr.join(";");

            chrome.storage.local.set({
              ignoreUsers: newList
            });

            document.getElementById("ignoreUsers").value = newList;

            div.remove();

          });

        });
      
      resultDiv.appendChild(div);

    });

  });

});

document.getElementById("selectAll").addEventListener("click", () => {

  if (processRunning || loadingData) return;

  const checkboxes = document.querySelectorAll("#result .removeUser");
  checkboxes.forEach(cb => cb.checked = true);

});

document.getElementById("unfollow").addEventListener("click", async () => {

  if (processRunning || loadingData) return;

  const tabs = await chrome.tabs.query({
    url: "*://www.instagram.com/*"
  });

  const tab = tabs.find(t => !t.url.includes("/direct/")) || tabs[0];

  if (!tab) {
    document.getElementById("status").innerText =
      "Abra o Instagram em uma aba primeiro.";
    return;
  }

  const selected = Array.from(
    document.querySelectorAll("#result .removeUser:checked")
  ).map(cb => cb.dataset.id);

  if (selected.length === 0) return;

  processRunning = true;

  document.getElementById("summary").innerHTML = "";
  document.getElementById("result").innerHTML = "";
  document.getElementById("status").innerText =
    `Iniciando processo para ${selected.length} usuários...`;

  document.getElementById("cancel").style.display = "block";

  setButtonsDisabled(true);

  chrome.tabs.sendMessage(tab.id, {
    action: "UNFOLLOW_SELECTED",
    ids: selected
  });

});

document.getElementById("cancel").addEventListener("click", async () => {

  const tabs = await chrome.tabs.query({
    url: "*://www.instagram.com/*"
  });

  const tab = tabs.find(t => !t.url.includes("/direct/")) || tabs[0];

  if (!tab) return;

  chrome.tabs.sendMessage(tab.id, { action: "CANCEL_UNFOLLOW" });

});

chrome.runtime.onMessage.addListener((message) => {

  const status = document.getElementById("status");

  if (message.type === "SCAN_PROGRESS") {

    const percent = Math.min(
      100,
      Math.floor((message.count / (message.total || 1)) * 100)
    );

    if (message.endpoint === "followers") {

      const container = document.getElementById("progressFollowers");
      const bar = document.getElementById("barFollowers");
      const text = document.getElementById("textFollowers");

      container.style.display = "block";

      bar.style.width = percent + "%";

      text.innerText =
        `${message.count} / ${message.total} (${percent}%)`;

      status.innerText = "Lendo usuários...";

    }

    if (message.endpoint === "following") {

      const container = document.getElementById("progressFollowing");
      const bar = document.getElementById("barFollowing");
      const text = document.getElementById("textFollowing");

      container.style.display = "block";

      bar.style.width = percent + "%";

      text.innerText =
        `${message.count} / ${message.total} (${percent}%)`;

      status.innerText = "Lendo usuários...";

    }

    return;
  }

  if (message.type === "PROGRESS_UPDATE") {

    if (message.waiting) {

      let seconds = Math.floor(message.waitTime / 1000);

      if (countdownInterval) clearInterval(countdownInterval);

      countdownInterval = setInterval(() => {

        status.innerText =
`Executados: ${message.success}/${message.total}
Restantes: ${message.remaining}

Executa-se de 5 em 5 unfollows a cada minuto para evitar bloqueio da conta.

Próximo lote em: ${seconds}s`;

        seconds--;

        if (seconds < 0) clearInterval(countdownInterval);

      }, 1000);

    } else {

      status.innerText =
`Executados: ${message.success}/${message.total}
Restantes: ${message.remaining}`;
    }
  }

  if (message.type === "PROCESS_FINISHED") {

    if (countdownInterval) clearInterval(countdownInterval);

    processRunning = false;

    setButtonsDisabled(false);

    document.getElementById("cancel").style.display = "none";
    document.getElementById("progressText").innerText = "";

    status.innerText =
      message.cancelled
        ? "Processo cancelado."
        : "Processo concluído.";
  }

});

document.addEventListener("DOMContentLoaded", () => {

  const loadButton = document.getElementById("load");

  // desabilita inicialmente
  loadButton.disabled = true;
  loadButton.style.opacity = "0.5";

  // habilita após 2 segundos
  setTimeout(() => {
    loadButton.disabled = false;
    loadButton.style.opacity = "1";
  }, 2000);

  chrome.storage.local.get(["lastUsername","ignoreUsers"], (result) => {

    if (result.lastUsername) {
      document.getElementById("targetUser").value = result.lastUsername;
    }

    if (result.ignoreUsers) {
      document.getElementById("ignoreUsers").value = result.ignoreUsers;
    }

  });

});