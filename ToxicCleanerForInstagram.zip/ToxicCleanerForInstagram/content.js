let cancelRequested = false;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

  if (request.action === "LOAD_DATA") {
    loadData(request.username, request.ignoreList)
      .then(sendResponse)
      .catch(err => {
        console.error("Erro interno:", err);
        sendResponse({ error: "Falha ao processar dados." });
      });
    return true;
  }

  if (request.action === "UNFOLLOW_SELECTED") {
    unfollowSelected(request.ids)
      .then(sendResponse)
      .catch(err => {
        console.error("Erro no unfollow:", err);
        sendResponse({ error: "Falha ao executar unfollow." });
      });
    return true;
  }

  if (request.action === "CANCEL_UNFOLLOW") {
    cancelRequested = true;
  }

});

async function getUserIdFromUsername(username) {

  const response = await fetch(
    `/api/v1/users/web_profile_info/?username=${username}`,
    {
      credentials: "include",
      headers: {
        "x-ig-app-id": getAppId(),
        "accept": "*/*"
      }
    }
  );

  if (!response.ok) return null;

  const data = await response.json();

  return {
    id: data?.data?.user?.id || null,
    followers: data?.data?.user?.edge_followed_by?.count || 0,
    following: data?.data?.user?.edge_follow?.count || 0
  };
}

function getAppId() {
  const match = document.documentElement.innerHTML.match(/"app_id":"(\d+)"/);
  return match ? match[1] : "936619743392459";
}

async function fetchAll(endpoint, userId, total) {

  let results = [];
  let maxId = null;
  let hasMore = true;

  const csrftoken = document.cookie
    .split("; ")
    .find(row => row.startsWith("csrftoken="))
    ?.split("=")[1];

  while (hasMore) {

    const url = new URL(
      `/api/v1/friendships/${userId}/${endpoint}/`,
      window.location.origin
    );

    url.searchParams.set("count", "50");

    if (maxId) url.searchParams.set("max_id", maxId);

    const response = await fetch(url.toString(), {
      method: "GET",
      credentials: "include",
      headers: {
        "x-csrftoken": csrftoken,
        "x-ig-app-id": getAppId(),
        "accept": "*/*"
      }
    });

    if (!response.ok) break;

    const data = await response.json();

    if (!data || !Array.isArray(data.users)) break;

    results = results.concat(data.users);

    chrome.runtime.sendMessage({
      type: "SCAN_PROGRESS",
      endpoint: endpoint,
      count: results.length,
      total: total
    });

    hasMore = data.has_more === true;
    maxId = data.next_max_id || null;

    const delay = 400 + Math.random() * 400;
    await new Promise(r => setTimeout(r, delay));
  }

  return results;
}

async function loadData(username, ignoreList = []) {
  const userInfo = await getUserIdFromUsername(username);

  if (!userInfo || !userInfo.id) {
    return { error: "User ID não encontrado." };
  }

  const userId = userInfo.id;
  const totalFollowers = userInfo.followers;
  const totalFollowing = userInfo.following;

  const [followers, following] = await Promise.all([
    fetchAll("followers", userId, totalFollowers),
    fetchAll("following", userId, totalFollowing)
  ]);

  const followerUsernames = new Set(
    followers
      .filter(u => u && u.username)
      .map(u => u.username.toLowerCase())
  );

  const notFollowingBack = following.filter(user => {

    if (!user || !user.username) return false;

    const usernameLower = user.username.toLowerCase();

    if (followerUsernames.has(usernameLower)) return false;

    if (ignoreList.includes(usernameLower)) return false;

    return true;

  });

  notFollowingBack.sort((a, b) =>
    a.username.localeCompare(b.username)
  );

  const list = notFollowingBack.map(u => ({
    username: u.username,
    fullName: u.full_name || "",
    id: u.pk,
    profileUrl: `https://www.instagram.com/${u.username}/`
  }));

  return {
    followers: followers.length,
    following: following.length,
    totalFollowers,
    totalFollowing,
    notFollowingBack: notFollowingBack.length,
    list
  };
}

async function unfollowUser(userId) {
  const csrftoken = document.cookie
    .split("; ")
    .find(row => row.startsWith("csrftoken="))
    ?.split("=")[1];

  const response = await fetch(
    `/api/v1/friendships/destroy/${userId}/`,
    {
      method: "POST",
      credentials: "include",
      headers: {
        "x-csrftoken": csrftoken,
        "x-ig-app-id": getAppId(),
        "content-type": "application/x-www-form-urlencoded"
      },
      body: ""
    }
  );

  return response.ok;
}


async function unfollowSelected(ids) {

  cancelRequested = false;

  const BATCH_SIZE = 5;
  const WAIT_TIME = 62000;

  let success = 0;
  let remaining = ids.length;

  for (let i = 0; i < ids.length; i += BATCH_SIZE) {

    if (cancelRequested) break;

    const batch = ids.slice(i, i + BATCH_SIZE);

    for (const id of batch) {

      if (cancelRequested) break;

      const ok = await unfollowUser(id);
      if (ok) success++;
      remaining--;

      chrome.runtime.sendMessage({
        type: "PROGRESS_UPDATE",
        success,
        remaining,
        total: ids.length,
        waiting: false
      });

      await new Promise(r => setTimeout(r, 2000));
    }

    if (remaining > 0 && !cancelRequested) {

      chrome.runtime.sendMessage({
        type: "PROGRESS_UPDATE",
        success,
        remaining,
        total: ids.length,
        waiting: true,
        waitTime: WAIT_TIME
      });

      const start = Date.now();

      while (Date.now() - start < WAIT_TIME) {
        if (cancelRequested) break;
        await new Promise(r => setTimeout(r, 1000));
      }
    }
  }

  chrome.runtime.sendMessage({
    type: "PROCESS_FINISHED",
    success,
    remaining,
    cancelled: cancelRequested
  });

  return { success };
}